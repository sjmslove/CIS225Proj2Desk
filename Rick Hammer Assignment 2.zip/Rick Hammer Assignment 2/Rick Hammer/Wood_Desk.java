
/**
 * Write a description of class Wood_Desk here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Wood_Desk
{
    // instance variables - replace the example below with your own
    private int Length;
    private int Width;
    private int TotalSize;
    private String Type;
    private int DrawerNumber;
    private int TotalCost;
    private String CustomerName;
    private int OrderNumber;
    private int typeCost;
    private int OverSize;
    
    /**
     * Constructor for objects of class Wood_Desk
     */
    public Wood_Desk(int leng, int wide)
    {
        Length = leng;
        Width = wide;
        TotalSize = Length * Width;
        Type = "Pine";
        DrawerNumber = 0;
        TotalCost = 0;
        CustomerName = "Mr. Smith";
        OrderNumber = 1;
    }

    /**
     * overall display
     */
    
    public void finalReport()
    {
        if (TotalSize > 750) 
        {
            OverSize = 50;
        }
        else {
            OverSize = 0;
        }
        TotalCost = 200 + (DrawerNumber * 30) + typeCost + OverSize;
        
        System.out.println("");
        System.out.println("Customer: " + CustomerName);
        System.out.println("Order Number: " + OrderNumber);
        System.out.println(" ");
        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$");
        System.out.println("Total Cost: $" + TotalCost);
        System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$");
        System.out.println(" ");
        System.out.println("Total Size: " + TotalSize + " square inches");
        System.out.println("Length: " + Length + " inches");
        System.out.println("Width: " + Width + " inches");
        System.out.println(" ");
        System.out.println("Wood Type: " + Type + " (Pine = $0, Oak = $125, Mahogany = $150)");
        System.out.println("Number of Drawers: " + DrawerNumber + " ($30 per Drawer)");
        System.out.println(" ");
        System.out.println("Any desk over 750 square inches will be charged an extra $50");
        System.out.println("Minimum desk cost is $200");
    }
    /**
     * customer name
     */
    public String Name(String fullName)
    {
        CustomerName = fullName;
        return CustomerName;
    }
    
    /**
     * order id
     */
    public int newOrder()
    {
        int orderNum;
        orderNum = 1;
        OrderNumber = OrderNumber + orderNum;
        return OrderNumber;
    }
    /**
     * desk type
     */
    public void woodType(String tree)
    {
        if (tree == "pine")
        {
            Type = "Pine";
            typeCost = 0;
        }
        else if (tree == "oak"){
            Type = "Oak";
            typeCost = 125;
        }
        else if (tree == "mahogany"){
            Type = "Mahogany";
            typeCost = 150;
        }
        else {
            System.out.println("Sorry, that is not an option, please check spelling" + tree);
        }
    }
    
    /**
     * drawercount
     */
    public void DrawerCount(int count)
    {
        if (count >= 0)
        {
            DrawerNumber = count;
        }
        else{
            System.out.println("Not a sufficient number of drawers, please try again");
        }
    }
      
}
