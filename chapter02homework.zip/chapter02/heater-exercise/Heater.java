
/**
 * Write a description of class Heater here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Heater
{
    // instance variables - replace the example below with your own
    private int tempurature;
    private int max;
    private int min;
    private int increment;

    /**
     * Constructor for objects of class Heater
     */
    public Heater()
    {
        // initialise instance variables
        tempurature = 15;
        min = 2;
        max = 27;
        increment = 5;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void warmer()
    {
        if (tempurature + increment <= max){
            tempurature = tempurature + increment;
        }
        else {
            System.out.println("Temp is to close to the maximum tempurature");
            System.out.println("Current Temp:" + tempurature);
            System.out.println("Current Max:" + max);
            System.out.println("Current Increment:" + increment);
        }
    }
    
    public void cooler()
    {
        if (tempurature - increment >= min){
            tempurature = tempurature - increment;
        }
        else {
            System.out.println("Temp is to close to the maximum tempurature");
            System.out.println("Current Temp:" + tempurature);
            System.out.println("Current Min:" + min);
            System.out.println("Current Increment:" + increment);
        }
    }
    
    public int setMaxTemp(int high)
    {
        max = high;
        return max;
    }
    
    public int setMinTemp (int low)
    {
        min = low;
        return min;
    }
    
    public void setIncrement (int increase)
    {
        if (increase > 0){
            increment = increase;
        }
        else {
            System.out.println("Not a reasonable increment");
        }
    }
       
    
    public void getTempurature()
    {
        System.out.println("The Current Tempurature is " + tempurature);
        System.out.println("Minimum Temp: " + min);
        System.out.println("Maximum Temp: " + max);
        System.out.println("Incremental Change: " + increment);
    }
    
}
