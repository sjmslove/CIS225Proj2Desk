import java.io.*;

/**
 * A class that maintains information on a book.
 * This might form part of a larger application such
 * as a library system, for instance.
 *
 * @author (Insert your name here.)
 * @version (Insert today's date here.)
 */
public class Book
{
    // The fields.
    private String author;
    private String title;
    private int pages;
    private String refNumber;
    private int borrowed;
    private String CourseText;

    /**
     * Set the author and title fields when this object
     * is constructed.
     */
    public Book(String bookAuthor, String bookTitle)
    {
        author = bookAuthor;
        title = bookTitle;
    }

    public String getAuthor()
    {
        return author;
    }
    
    public String getTitle()
    {
        return title;
    }
    
    public int getPages(int count)
    {
        pages = count;
        return pages;
    }
    
    public String getrefNumber(String ref)
    {
        refNumber = ref;
        return refNumber;
    }
    
    public void printAuthor()
    {
        System.out.println("The Author is " + author +".");
    }
    
    public void printTitle()
    {
        System.out.println("The Title is " + title + ".");
    }
    
    public void printPages()
    {
        System.out.println("The number of pages in this book is " + pages + ".");
    }
    
    public void printDetails()
    {
        System.out.println("Author:" + author);
        System.out.println("Title:" + title);
        System.out.println("Pages:" + pages);
        System.out.println("Number of Times Borrowed:" + borrowed);
        System.out.println("CourseText?:" + CourseText);
        if (refNumber.length() == 0){
            System.out.println("ZZZ");
        }
        else {
            System.out.println("Reference Number:" + refNumber);
        }                
    }
    
   public void setRefNumber(String ref)
   {
       refNumber = ref;
       if (refNumber.length() > 3){
       refNumber = ref;
       }
       else {
           System.out.println("Error, not long enough reference number.");
       }
   }
   
   
   
   public void borrowBook()
   {
       int bookcount;
       bookcount = borrowed;
       borrowed = bookcount + 1;
   }
    
   public int borrowed()
   {
       return borrowed;
   }
   
   public String isCourseText(String verify)
   {
       if (verify == "no"){
           CourseText = "no";
       }
       else if (verify == "yes") {
           CourseText = "yes";
       }
       else {
           System.out.println("You have entered something wrong");
       }
       return CourseText;
   }
}